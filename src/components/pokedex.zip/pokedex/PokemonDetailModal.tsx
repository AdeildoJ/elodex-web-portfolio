import { useEffect, useMemo, useState } from "react";
import { doc, getDoc, setDoc } from "firebase/firestore";
import { db } from "@/lib/firebase";
import {
  PokemonSpecies,
  PokemonType,
} from "@/components/pokedex/pokedexTypes";
import movesJson from "@/data/moves.json";
import pokemonMovesJson from "@/data/pokemonMoves.json";

/**
 * Tabela oficial de tipo → multiplicadores (Ataque → Defesa)
 */
type TypeChartEntry = {
  double: PokemonType[];
  half: PokemonType[];
  zero: PokemonType[];
};

const TYPE_CHART: Record<PokemonType, TypeChartEntry> = {
  normal: {
    double: [],
    half: ["rock", "steel"],
    zero: ["ghost"],
  },
  fire: {
    double: ["grass", "ice", "bug", "steel"],
    half: ["fire", "water", "rock", "dragon"],
    zero: [],
  },
  water: {
    double: ["fire", "rock", "ground"],
    half: ["water", "grass", "dragon"],
    zero: [],
  },
  electric: {
    double: ["water", "flying"],
    half: ["electric", "grass", "dragon"],
    zero: ["ground"],
  },
  grass: {
    double: ["water", "ground", "rock"],
    half: ["fire", "grass", "dragon", "bug", "poison", "flying", "steel"],
    zero: [],
  },
  ice: {
    double: ["grass", "ground", "dragon", "flying"],
    half: ["fire", "water", "ice", "steel"],
    zero: [],
  },
  fighting: {
    double: ["rock", "steel", "ice", "normal", "dark"],
    half: ["flying", "psychic", "poison", "bug", "fairy"],
    zero: ["ghost"],
  },
  poison: {
    double: ["grass", "fairy"],
    half: ["poison", "ground", "rock", "ghost"],
    zero: ["steel"],
  },
  ground: {
    double: ["fire", "steel", "rock", "poison", "electric"],
    half: ["bug", "grass"],
    zero: ["flying"],
  },
  flying: {
    double: ["grass", "fighting", "bug"],
    half: ["electric", "rock", "steel"],
    zero: [],
  },
  psychic: {
    double: ["fighting", "poison"],
    half: ["psychic", "steel"],
    zero: ["dark"],
  },
  bug: {
    double: ["grass", "dark", "psychic"],
    half: ["fire", "fighting", "poison", "flying", "steel", "fairy", "ghost"],
    zero: [],
  },
  rock: {
    double: ["fire", "flying", "bug", "ice"],
    half: ["fighting", "ground", "steel"],
    zero: [],
  },
  ghost: {
    double: ["psychic", "ghost"],
    half: ["dark"],
    zero: ["normal"],
  },
  dragon: {
    double: ["dragon"],
    half: ["steel"],
    zero: ["fairy"],
  },
  dark: {
    double: ["psychic", "ghost"],
    half: ["dark", "fighting", "fairy"],
    zero: [],
  },
  steel: {
    double: ["ice", "rock", "fairy"],
    half: ["fire", "water", "electric", "steel"],
    zero: [],
  },
  fairy: {
    double: ["dark", "dragon", "fighting"],
    half: ["fire", "poison", "steel"],
    zero: [],
  },
};

function getMultiplierAgainstDefender(
  attackType: PokemonType,
  defenderTypes: PokemonType[]
): number {
  const chart = TYPE_CHART[attackType];
  if (!chart) return 1;

  let multiplier = 1;

  for (const def of defenderTypes) {
    if (chart.zero.includes(def)) {
      multiplier *= 0;
    } else if (chart.double.includes(def)) {
      multiplier *= 2;
    } else if (chart.half.includes(def)) {
      multiplier *= 0.5;
    } else {
      multiplier *= 1;
    }
  }

  return multiplier;
}

function getTypeTables(defenderTypes: PokemonType[]) {
  const weak: { type: PokemonType; value: number }[] = [];
  const resist: { type: PokemonType; value: number }[] = [];
  const immune: PokemonType[] = [];
  const normal: PokemonType[] = [];

  const ALL_TYPES: PokemonType[] = [
    "normal",
    "fire",
    "water",
    "electric",
    "grass",
    "ice",
    "fighting",
    "poison",
    "ground",
    "flying",
    "psychic",
    "bug",
    "rock",
    "ghost",
    "dragon",
    "dark",
    "steel",
    "fairy",
  ];

  for (const atk of ALL_TYPES) {
    const mult = getMultiplierAgainstDefender(atk, defenderTypes);

    if (mult === 0) {
      immune.push(atk);
    } else if (mult === 1) {
      normal.push(atk);
    } else if (mult > 1) {
      weak.push({ type: atk, value: mult });
    } else if (mult < 1) {
      resist.push({ type: atk, value: mult });
    }
  }

  return { weak, resist, immune, normal };
}

/**
 * Pré-visualização de stats usando fórmulas oficiais com
 * IV 31, EV 0, natureza neutra (1.0)
 */
function calcPreviewStats(
  baseStats: PokemonSpecies["baseStats"],
  level: number
) {
  if (!baseStats) {
    return null;
  }

  const iv = 31;
  const ev = 0;
  const nature = 1.0;
  const floor = Math.floor;

  const hp =
    baseStats.hp === 1
      ? 1
      : floor(((2 * baseStats.hp + iv + floor(ev / 4)) * level) / 100) +
        level +
        10;

  const makeStat = (base: number) => {
    const statBase =
      floor(((2 * base + iv + floor(ev / 4)) * level) / 100) + 5;
    return floor(statBase * nature);
  };

  return {
    hp,
    attack: makeStat(baseStats.attack),
    defense: makeStat(baseStats.defense),
    specialAttack: makeStat(baseStats.specialAttack),
    specialDefense: makeStat(baseStats.specialDefense),
    speed: makeStat(baseStats.speed),
  };
}

/**
 * Config EloDex por espécie + versão
 */
type IvMode = "random" | "range";
type EvMode = "none" | "default";

type PokemonConfig = {
  versionId: string;
  speciesId: string;
  available: boolean;
  levelMin: number | null;
  levelMax: number | null;

  ivMode: IvMode;
  ivMin: number;
  ivMax: number;

  evMode: EvMode;

  natureMode: "any" | "restricted";
  allowedNatures: string[];

  abilityMode: "randomNormal" | "noHidden" | "fixed";
  fixedAbilityName: string | null;

  quantityLimit: number | null;
  unlimitedQuantity: boolean;

  appearanceRate: number; // %
  shinyRate: number; // %
  corruptedRate: number; // %
  glamourRate: number; // %

  methods: {
    radar: { enabled: boolean; appearanceRate: number | null };
    km: { enabled: boolean; minKm: number | null };
    rod: { enabled: boolean; failureChance: number | null };
    egg: { enabled: boolean; fromMysteryEgg: boolean };
  };
};

const DEFAULT_CONFIG = (versionId: string, speciesId: string): PokemonConfig => ({
  versionId,
  speciesId,
  available: false,
  levelMin: null,
  levelMax: 40,

  ivMode: "random",
  ivMin: 0,
  ivMax: 31,

  evMode: "none",

  natureMode: "any",
  allowedNatures: [],

  abilityMode: "randomNormal",
  fixedAbilityName: null,

  quantityLimit: null,
  unlimitedQuantity: true,

  appearanceRate: 3,
  shinyRate: 0.05,
  corruptedRate: 1,
  glamourRate: 5,

  methods: {
    radar: { enabled: true, appearanceRate: null },
    km: { enabled: false, minKm: null },
    rod: { enabled: false, failureChance: 10 },
    egg: { enabled: false, fromMysteryEgg: false },
  },
});

/**
 * Movimentos
 */
type MoveData = {
  id: string;
  name: string;
  type: PokemonType;
  power: number | null;
  accuracy: number | null;
  pp: number | null;
  damageClass: "physical" | "special" | "status";
  priority?: number | null;
};

type LearnMethod = "level-up" | "machine" | "egg" | "tutor";

type PokemonMoveEntry = {
  moveId: string;
  method: LearnMethod;
  level?: number | null;
};

type LearnsetWithMove = {
  entry: PokemonMoveEntry;
  move: MoveData;
};

type GroupedMoves = {
  levelUp: LearnsetWithMove[];
  machine: LearnsetWithMove[];
  egg: LearnsetWithMove[];
  tutor: LearnsetWithMove[];
};

type PokemonDetailModalProps = {
  pokemon: PokemonSpecies;
  versionId: string;
  onClose: () => void;
};

const damageClassLabel = (dc: MoveData["damageClass"]) => {
  if (dc === "physical") return "Físico";
  if (dc === "special") return "Especial";
  return "Status";
};

const typeBadges = (t: PokemonType) => t.charAt(0).toUpperCase() + t.slice(1);
const formatDexNumber = (n: number) => `#${String(n).padStart(4, "0")}`;

// Tipos auxiliares para os JSONs de movimentos / learnset
type RawMoveJson = {
  name?: string;
  type?: PokemonType;
  power?: number | null;
  accuracy?: number | null;
  pp?: number | null;
  damageClass?: MoveData["damageClass"] | string;
  priority?: number | null;
};

type MovesJsonMap = Record<string, RawMoveJson>;

type PokemonMovesJsonEntry = {
  moves?: PokemonMoveEntry[];
};

type PokemonMovesJsonMap = Record<string, PokemonMovesJsonEntry>;

export default function PokemonDetailModal({
  pokemon,
  versionId,
  onClose,
}: PokemonDetailModalProps) {
  const [activeTab, setActiveTab] = useState<
    "encyclopedia" | "types" | "moves" | "config"
  >("encyclopedia");

  const [config, setConfig] = useState<PokemonConfig | null>(null);
  const [configLoaded, setConfigLoaded] = useState(false);
  const [saving, setSaving] = useState(false);
  const [previewLevel, setPreviewLevel] = useState<number>(30);
  const [showShiny, setShowShiny] = useState(false);

  const [movesLoading, setMovesLoading] = useState(false);
  const [learnsetEntries, setLearnsetEntries] = useState<PokemonMoveEntry[]>(
    []
  );
  const [movesData, setMovesData] = useState<Record<string, MoveData>>({});
  const [movesLoaded, setMovesLoaded] = useState(false);

  // Sempre que mudar de espécie/versão, limpa estado
  useEffect(() => {
    setConfig(null);
    setConfigLoaded(false);
    setLearnsetEntries([]);
    setMovesData({});
    setMovesLoaded(false);
  }, [pokemon.id, versionId]);

  // 🔥 Lazy load da CONFIG – só quando aba "config" for aberta
  useEffect(() => {
    if (activeTab !== "config") return;
    if (configLoaded) return;

    let cancelled = false;

    async function loadConfig() {
      try {
        const docId = `${versionId}_${pokemon.id}`;
        const ref = doc(db, "pokedexConfig", docId);
        const snap = await getDoc(ref);

        if (cancelled) return;

        if (snap.exists()) {
          setConfig(snap.data() as PokemonConfig);
        } else {
          setConfig(DEFAULT_CONFIG(versionId, pokemon.id));
        }
        setConfigLoaded(true);
      } catch (err) {
        console.error("Erro ao carregar configuração da Pokédex:", err);
        if (!cancelled) {
          setConfig(DEFAULT_CONFIG(versionId, pokemon.id));
          setConfigLoaded(true);
        }
      }
    }

    loadConfig();

    return () => {
      cancelled = true;
    };
  }, [activeTab, configLoaded, pokemon.id, versionId]);

  // 🔥 Lazy load dos MOVES via JSON – só quando aba "moves" for aberta
  useEffect(() => {
    if (activeTab !== "moves") return;
    if (movesLoaded) return;

    setMovesLoading(true);

    try {
      const speciesKey = String(pokemon.id);

      const allPokemonMoves = pokemonMovesJson as PokemonMovesJsonMap;
      const speciesData = allPokemonMoves[speciesKey];

      const entries = speciesData?.moves ?? [];
      setLearnsetEntries(entries);

      const allMoves = movesJson as MovesJsonMap;

      const uniqueIds = Array.from(new Set(entries.map((e) => e.moveId)));
      const movesMap: Record<string, MoveData> = {};

      for (const id of uniqueIds) {
        const md = allMoves[id];
        if (!md) continue;

        const moveData: MoveData = {
          id,
          name: md.name ?? id,
          type: (md.type ?? "normal") as PokemonType,
          power:
            md.power === null || md.power === undefined
              ? null
              : Number(md.power),
          accuracy:
            md.accuracy === null || md.accuracy === undefined
              ? null
              : Number(md.accuracy),
          pp:
            md.pp === null || md.pp === undefined ? null : Number(md.pp),
          damageClass:
            (md.damageClass as MoveData["damageClass"]) ?? "physical",
          priority:
            md.priority === null || md.priority === undefined
              ? 0
              : Number(md.priority),
        };

        movesMap[id] = moveData;
      }

      setMovesData(movesMap);
      setMovesLoaded(true);
    } catch (error) {
      console.error("Erro ao carregar movimentos a partir dos JSONs:", error);
    } finally {
      setMovesLoading(false);
    }
  }, [activeTab, movesLoaded, pokemon.id]);

  async function handleSave() {
    if (!config) return;
    try {
      setSaving(true);
      const docId = `${versionId}_${pokemon.id}`;
      const ref = doc(db, "pokedexConfig", docId);
      await setDoc(ref, config, { merge: true });
    } catch (err) {
      console.error("Erro ao salvar configuração da Pokédex:", err);
    } finally {
      setSaving(false);
    }
  }

  const typeTables = useMemo(
    () => getTypeTables(pokemon.types),
    [pokemon.types]
  );

  const previewStats = useMemo(
    () => calcPreviewStats(pokemon.baseStats, previewLevel),
    [pokemon.baseStats, previewLevel]
  );

  const groupedMoves = useMemo<GroupedMoves>(() => {
    const base: GroupedMoves = {
      levelUp: [],
      machine: [],
      egg: [],
      tutor: [],
    };

    for (const entry of learnsetEntries) {
      const move = movesData[entry.moveId];
      if (!move) continue;

      const methodKey: keyof GroupedMoves =
        entry.method === "level-up"
          ? "levelUp"
          : entry.method === "machine"
          ? "machine"
          : entry.method === "egg"
          ? "egg"
          : "tutor";

      base[methodKey].push({ entry, move });
    }

    base.levelUp.sort((a, b) => {
      const la = a.entry.level ?? 0;
      const lb = b.entry.level ?? 0;
      if (la !== lb) return la - lb;
      return a.move.name.localeCompare(b.move.name);
    });

    base.machine.sort((a, b) => a.move.name.localeCompare(b.move.name));
    base.egg.sort((a, b) => a.move.name.localeCompare(b.move.name));
    base.tutor.sort((a, b) => a.move.name.localeCompare(b.move.name));

    return base;
  }, [learnsetEntries, movesData]);

  const hasShiny = Boolean(pokemon.shinySpriteUrl);
  const currentSprite =
    showShiny && hasShiny ? pokemon.shinySpriteUrl : pokemon.spriteUrl;
  const pokemonName =
    pokemon.name.charAt(0).toUpperCase() + pokemon.name.slice(1);

  return (
    <div className="fixed inset-0 z-40 flex items-center justify-center">
      <div
        className="absolute inset-0 bg-black/60"
        onClick={onClose}
        aria-hidden="true"
      />

      <div className="relative z-50 w-full max-w-5xl max-h-[90vh] rounded-2xl bg-slate-950 border border-slate-800 shadow-2xl flex flex-col">
        {/* Cabeçalho */}
        <div className="flex items-start gap-4 border-b border-slate-800 px-5 py-4">
          <div className="flex items-center gap-4 flex-1">
            <div className="relative flex flex-col items-center justify-center">
              {/* eslint-disable-next-line @next/next/no-img-element */}
              {currentSprite ? (
                <img
                  src={currentSprite}
                  alt={pokemon.name}
                  className="w-24 h-24 object-contain drop-shadow-[0_0_20px_rgba(79,70,229,0.6)]"
                />
              ) : (
                <div className="w-24 h-24 flex items-center justify-center text-xs text-slate-500 border border-dashed border-slate-700 rounded-xl">
                  Sem sprite
                </div>
              )}

              <div className="mt-2 flex items-center gap-1 text-[11px] text-slate-300">
                <span className="px-2 py-0.5 rounded-full bg-slate-900/80 border border-slate-700">
                  {formatDexNumber(pokemon.dexNumber)}
                </span>
              </div>

              {hasShiny && (
                <button
                  type="button"
                  onClick={() => setShowShiny((prev) => !prev)}
                  className="mt-2 inline-flex items-center gap-1 rounded-full bg-amber-500/10 border border-amber-400/40 px-2 py-0.5 text-[11px] text-amber-200 hover:bg-amber-500/20 transition"
                >
                  {showShiny ? "Ver normal" : "Ver Shiny"}
                </button>
              )}
            </div>

            <div className="flex-1">
              <div className="flex items-center justify-between gap-2">
                <div>
                  <h2 className="text-xl font-bold text-slate-50">
                    {pokemonName}
                  </h2>
                  <p className="text-xs text-slate-400 mt-0.5">
                    Espécie cadastrada no EloDex Admin
                  </p>
                </div>
                <div className="flex flex-col items-end gap-1">
                  <span className="inline-flex items-center rounded-full bg-emerald-600/20 px-3 py-1 text-[11px] font-semibold text-emerald-300">
                    {pokemon.pokemonClass || "Comum"}
                  </span>
                  <div className="flex flex-wrap gap-1 justify-end">
                    {pokemon.types.map((t) => (
                      <span
                        key={t}
                        className="rounded-full bg-slate-800 px-2 py-0.5 text-[11px] font-medium text-slate-100"
                      >
                        {typeBadges(t)}
                      </span>
                    ))}
                  </div>
                </div>
              </div>

              <div className="mt-3 flex flex-wrap gap-4 text-[11px] text-slate-300">
                <span>
                  <span className="text-slate-500">Altura:</span>{" "}
                  {pokemon.height != null ? `${pokemon.height}` : "--"}
                </span>
                <span>
                  <span className="text-slate-500">Peso:</span>{" "}
                  {pokemon.weight != null ? `${pokemon.weight}` : "--"}
                </span>
              </div>
            </div>
          </div>

          <button
            type="button"
            onClick={onClose}
            className="text-slate-400 hover:text-slate-100 text-xl leading-none"
          >
            ✕
          </button>
        </div>

        {/* Abas */}
        <div className="px-5 pt-3 flex flex-wrap gap-2 border-b border-slate-800">
          <button
            type="button"
            className={`px-3 py-1.5 text-xs font-semibold rounded-full ${
              activeTab === "encyclopedia"
                ? "bg-indigo-600 text-white"
                : "bg-slate-900 text-slate-300 hover:bg-slate-800"
            }`}
            onClick={() => setActiveTab("encyclopedia")}
          >
            Enciclopédia
          </button>
          <button
            type="button"
            className={`px-3 py-1.5 text-xs font-semibold rounded-full ${
              activeTab === "types"
                ? "bg-indigo-600 text-white"
                : "bg-slate-900 text-slate-300 hover:bg-slate-800"
            }`}
            onClick={() => setActiveTab("types")}
          >
            Tab de Tipos
          </button>
          <button
            type="button"
            className={`px-3 py-1.5 text-xs font-semibold rounded-full ${
              activeTab === "moves"
                ? "bg-indigo-600 text-white"
                : "bg-slate-900 text-slate-300 hover:bg-slate-800"
            }`}
            onClick={() => setActiveTab("moves")}
          >
            Movimentos
          </button>
          <button
            type="button"
            className={`px-3 py-1.5 text-xs font-semibold rounded-full ${
              activeTab === "config"
                ? "bg-indigo-600 text-white"
                : "bg-slate-900 text-slate-300 hover:bg-slate-800"
            }`}
            onClick={() => setActiveTab("config")}
          >
            Config EloDex
          </button>
        </div>

        {/* Conteúdo das abas */}
        <div className="flex-1 overflow-y-auto px-5 pb-4 pt-3 text-sm">
          {/* Enciclopédia */}
          {activeTab === "encyclopedia" && (
            <div className="space-y-4">
              <section>
                <h3 className="text-xs font-semibold text-slate-400 mb-1">
                  Enciclopédia
                </h3>
                <div className="grid grid-cols-2 md:grid-cols-3 gap-2 text-xs">
                  <div>
                    <span className="text-slate-400">Classe:</span>{" "}
                    <span className="text-slate-100">
                      {pokemon.pokemonClass || "Comum"}
                    </span>
                  </div>
                  <div>
                    <span className="text-slate-400">Altura:</span>{" "}
                    <span className="text-slate-100">
                      {pokemon.height != null ? `${pokemon.height}` : "--"}
                    </span>
                  </div>
                  <div>
                    <span className="text-slate-400">Peso:</span>{" "}
                    <span className="text-slate-100">
                      {pokemon.weight != null ? `${pokemon.weight}` : "--"}
                    </span>
                  </div>
                </div>
              </section>

              <section>
                <h3 className="text-xs font-semibold text-slate-400 mb-1">
                  Descrição da Pokédex (PT-BR)
                </h3>
                {pokemon.dexEntryPtBr ? (
                  <p className="text-xs text-slate-200 leading-relaxed">
                    {pokemon.dexEntryPtBr}
                  </p>
                ) : (
                  <p className="text-xs text-slate-400">
                    Ainda não há descrição cadastrada para esta espécie.
                  </p>
                )}
              </section>

              <section>
                <h3 className="text-xs font-semibold text-slate-400 mb-1">
                  Status base (oficiais)
                </h3>
                {pokemon.baseStats ? (
                  <div className="grid grid-cols-2 md:grid-cols-3 gap-x-4 gap-y-1 text-xs">
                    <div>HP: {pokemon.baseStats.hp}</div>
                    <div>Atk: {pokemon.baseStats.attack}</div>
                    <div>Def: {pokemon.baseStats.defense}</div>
                    <div>Sp. Atk: {pokemon.baseStats.specialAttack}</div>
                    <div>Sp. Def: {pokemon.baseStats.specialDefense}</div>
                    <div>Speed: {pokemon.baseStats.speed}</div>
                  </div>
                ) : (
                  <p className="text-xs text-slate-400">
                    Status base ainda não disponíveis para esta espécie.
                  </p>
                )}
                <p className="mt-1 text-[10px] text-slate-500">
                  Os status mostrados são base. O EloDex recalcula o valor final
                  com nível, IV, EV, natureza e glamour.
                </p>
              </section>

              {previewStats && (
                <section>
                  <h3 className="text-xs font-semibold text-slate-400 mb-1">
                    Pré-visualização de status (simulação)
                  </h3>
                  <div className="flex items-center gap-2 mb-2">
                    <span className="text-[11px] text-slate-400">Nível:</span>
                    <input
                      type="range"
                      min={1}
                      max={100}
                      value={previewLevel}
                      onChange={(e) => setPreviewLevel(Number(e.target.value))}
                    />
                    <span className="text-[11px] text-slate-200 w-8 text-right">
                      {previewLevel}
                    </span>
                  </div>
                  <div className="grid grid-cols-2 md:grid-cols-3 gap-x-4 gap-y-1 text-xs">
                    <div>HP: {previewStats.hp}</div>
                    <div>Atk: {previewStats.attack}</div>
                    <div>Def: {previewStats.defense}</div>
                    <div>Sp. Atk: {previewStats.specialAttack}</div>
                    <div>Sp. Def: {previewStats.specialDefense}</div>
                    <div>Speed: {previewStats.speed}</div>
                  </div>
                  <p className="mt-1 text-[10px] text-slate-500">
                    Simulação usando fórmulas oficiais com IV = 31, EV = 0 e
                    natureza neutra (1.0). A configuração EloDex ajusta as
                    regras de IV/EV/Natureza usadas na geração real.
                  </p>
                </section>
              )}
            </div>
          )}

          {/* Tab de tipos */}
          {activeTab === "types" && (
            <div className="space-y-4 text-[11px]">
              <section>
                <p className="text-slate-400 mb-2">
                  Cálculo automático baseado nos tipos defensivos de{" "}
                  <span className="text-slate-100 font-semibold">
                    {pokemonName}
                  </span>
                  . Os valores mostram quanto dano ele{" "}
                  <span className="font-semibold">recebe</span> de cada tipo.
                </p>
              </section>

              <section className="grid grid-cols-1 md:grid-cols-2 gap-3">
                <div>
                  <div className="font-semibold text-rose-300 mb-1">
                    FRACO CONTRA
                  </div>
                  {typeTables.weak.length === 0 ? (
                    <div className="text-slate-400">Nenhum tipo.</div>
                  ) : (
                    <div className="flex flex-wrap gap-1">
                      {typeTables.weak.map((w) => (
                        <span
                          key={w.type}
                          className="rounded-full bg-rose-900/50 px-2 py-0.5"
                        >
                          {typeBadges(w.type)} x{w.value}
                        </span>
                      ))}
                    </div>
                  )}
                </div>

                <div>
                  <div className="font-semibold text-emerald-300 mb-1">
                    RESISTENTE CONTRA
                  </div>
                  {typeTables.resist.length === 0 ? (
                    <div className="text-slate-400">Nenhum tipo.</div>
                  ) : (
                    <div className="flex flex-wrap gap-1">
                      {typeTables.resist.map((r) => (
                        <span
                          key={r.type}
                          className="rounded-full bg-emerald-900/40 px-2 py-0.5"
                        >
                          {typeBadges(r.type)} x{r.value}
                        </span>
                      ))}
                    </div>
                  )}
                </div>

                <div>
                  <div className="font-semibold text-slate-200 mb-1">
                    NEUTRO CONTRA
                  </div>
                  {typeTables.normal.length === 0 ? (
                    <div className="text-slate-400">Nenhum tipo.</div>
                  ) : (
                    <div className="flex flex-wrap gap-1">
                      {typeTables.normal.map((t) => (
                        <span
                          key={t}
                          className="rounded-full bg-slate-800 px-2 py-0.5"
                        >
                          {typeBadges(t)} x1
                        </span>
                      ))}
                    </div>
                  )}
                </div>

                <div>
                  <div className="font-semibold text-sky-300 mb-1">
                    IMUNE CONTRA
                  </div>
                  {typeTables.immune.length === 0 ? (
                    <div className="text-slate-400">Nenhum tipo.</div>
                  ) : (
                    <div className="flex flex-wrap gap-1">
                      {typeTables.immune.map((t) => (
                        <span
                          key={t}
                          className="rounded-full bg-sky-900/40 px-2 py-0.5"
                        >
                          {typeBadges(t)} x0
                        </span>
                      ))}
                    </div>
                  )}
                </div>
              </section>
            </div>
          )}

          {/* Movimentos */}
          {activeTab === "moves" && (
            <div className="space-y-4 text-xs">
              <section>
                <h3 className="text-xs font-semibold text-slate-400 mb-1">
                  Movimentos aprendíveis
                </h3>
                <p className="text-[11px] text-slate-400 mb-2">
                  Lista completa de movimentos que{" "}
                  <span className="text-slate-100 font-semibold">
                    {pokemonName}
                  </span>{" "}
                  pode aprender por nível, TM/HM, tutor e ovo (GEN 8 –
                  sword/shield).
                </p>
              </section>

              {movesLoading && (
                <p className="text-slate-300">Carregando movimentos...</p>
              )}

              {!movesLoading &&
                learnsetEntries.length === 0 &&
                Object.keys(movesData).length === 0 && (
                  <p className="text-slate-300">
                    Nenhum learnset cadastrado para esta espécie (verifique
                    src/data/pokemonMoves.json).
                  </p>
                )}

              {!movesLoading && learnsetEntries.length > 0 && (
                <div className="space-y-5">
                  {/* Level-up */}
                  <section>
                    <h4 className="text-xs font-semibold text-indigo-300 mb-2">
                      Por nível
                    </h4>
                    {groupedMoves.levelUp.length === 0 ? (
                      <p className="text-[11px] text-slate-400">
                        Nenhum movimento por nível.
                      </p>
                    ) : (
                      <div className="overflow-x-auto rounded-lg border border-slate-800">
                        <table className="min-w-full text-[11px]">
                          <thead className="bg-slate-900/80">
                            <tr className="text-left text-slate-300">
                              <th className="px-3 py-2">Nv</th>
                              <th className="px-3 py-2">Movimento</th>
                              <th className="px-3 py-2">Tipo</th>
                              <th className="px-3 py-2 text-right">Power</th>
                              <th className="px-3 py-2 text-right">Acc</th>
                              <th className="px-3 py-2 text-right">PP</th>
                              <th className="px-3 py-2">Classe</th>
                              <th className="px-3 py-2">Prio</th>
                            </tr>
                          </thead>
                          <tbody>
                            {groupedMoves.levelUp.map(({ entry, move }) => (
                              <tr
                                key={`${entry.moveId}-${entry.level ?? 0}`}
                                className="border-t border-slate-800/60"
                              >
                                <td className="px-3 py-1.5 text-slate-200">
                                  {entry.level ?? "-"}
                                </td>
                                <td className="px-3 py-1.5 text-slate-100">
                                  {move.name}
                                </td>
                                <td className="px-3 py-1.5">
                                  <span className="rounded-full bg-slate-800 px-2 py-0.5 text-[10px] text-slate-100">
                                    {typeBadges(move.type)}
                                  </span>
                                </td>
                                <td className="px-3 py-1.5 text-right">
                                  {move.power ?? "-"}
                                </td>
                                <td className="px-3 py-1.5 text-right">
                                  {move.accuracy ?? "-"}
                                </td>
                                <td className="px-3 py-1.5 text-right">
                                  {move.pp ?? "-"}
                                </td>
                                <td className="px-3 py-1.5">
                                  {damageClassLabel(move.damageClass)}
                                </td>
                                <td className="px-3 py-1.5">
                                  {move.priority && move.priority !== 0
                                    ? move.priority > 0
                                      ? `+${move.priority}`
                                      : move.priority
                                    : "-"}
                                </td>
                              </tr>
                            ))}
                          </tbody>
                        </table>
                      </div>
                    )}
                  </section>

                  {/* TM/HM */}
                  <section>
                    <h4 className="text-xs font-semibold text-sky-300 mb-2">
                      TM / HM (machine)
                    </h4>
                    {groupedMoves.machine.length === 0 ? (
                      <p className="text-[11px] text-slate-400">
                        Nenhum movimento por TM/HM.
                      </p>
                    ) : (
                      <div className="overflow-x-auto rounded-lg border border-slate-800">
                        <table className="min-w-full text-[11px]">
                          <thead className="bg-slate-900/80">
                            <tr className="text-left text-slate-300">
                              <th className="px-3 py-2">Movimento</th>
                              <th className="px-3 py-2">Tipo</th>
                              <th className="px-3 py-2 text-right">Power</th>
                              <th className="px-3 py-2 text-right">Acc</th>
                              <th className="px-3 py-2 text-right">PP</th>
                              <th className="px-3 py-2">Classe</th>
                              <th className="px-3 py-2">Prio</th>
                            </tr>
                          </thead>
                          <tbody>
                            {groupedMoves.machine.map(({ entry, move }) => (
                              <tr
                                key={entry.moveId}
                                className="border-t border-slate-800/60"
                              >
                                <td className="px-3 py-1.5 text-slate-100">
                                  {move.name}
                                </td>
                                <td className="px-3 py-1.5">
                                  <span className="rounded-full bg-slate-800 px-2 py-0.5 text-[10px] text-slate-100">
                                    {typeBadges(move.type)}
                                  </span>
                                </td>
                                <td className="px-3 py-1.5 text-right">
                                  {move.power ?? "-"}
                                </td>
                                <td className="px-3 py-1.5 text-right">
                                  {move.accuracy ?? "-"}
                                </td>
                                <td className="px-3 py-1.5 text-right">
                                  {move.pp ?? "-"}
                                </td>
                                <td className="px-3 py-1.5">
                                  {damageClassLabel(move.damageClass)}
                                </td>
                                <td className="px-3 py-1.5">
                                  {move.priority && move.priority !== 0
                                    ? move.priority > 0
                                      ? `+${move.priority}`
                                      : move.priority
                                    : "-"}
                                </td>
                              </tr>
                            ))}
                          </tbody>
                        </table>
                      </div>
                    )}
                  </section>

                  {/* Egg moves */}
                  <section>
                    <h4 className="text-xs font-semibold text-amber-300 mb-2">
                      Movimentos de Ovo (egg)
                    </h4>
                    {groupedMoves.egg.length === 0 ? (
                      <p className="text-[11px] text-slate-400">
                        Nenhum movimento de ovo.
                      </p>
                    ) : (
                      <div className="overflow-x-auto rounded-lg border border-slate-800">
                        <table className="min-w-full text-[11px]">
                          <thead className="bg-slate-900/80">
                            <tr className="text-left text-slate-300">
                              <th className="px-3 py-2">Movimento</th>
                              <th className="px-3 py-2">Tipo</th>
                              <th className="px-3 py-2 text-right">Power</th>
                              <th className="px-3 py-2 text-right">Acc</th>
                              <th className="px-3 py-2 text-right">PP</th>
                              <th className="px-3 py-2">Classe</th>
                              <th className="px-3 py-2">Prio</th>
                            </tr>
                          </thead>
                          <tbody>
                            {groupedMoves.egg.map(({ entry, move }) => (
                              <tr
                                key={entry.moveId}
                                className="border-t border-slate-800/60"
                              >
                                <td className="px-3 py-1.5 text-slate-100">
                                  {move.name}
                                </td>
                                <td className="px-3 py-1.5">
                                  <span className="rounded-full bg-slate-800 px-2 py-0.5 text-[10px] text-slate-100">
                                    {typeBadges(move.type)}
                                  </span>
                                </td>
                                <td className="px-3 py-1.5 text-right">
                                  {move.power ?? "-"}
                                </td>
                                <td className="px-3 py-1.5 text-right">
                                  {move.accuracy ?? "-"}
                                </td>
                                <td className="px-3 py-1.5 text-right">
                                  {move.pp ?? "-"}
                                </td>
                                <td className="px-3 py-1.5">
                                  {damageClassLabel(move.damageClass)}
                                </td>
                                <td className="px-3 py-1.5">
                                  {move.priority && move.priority !== 0
                                    ? move.priority > 0
                                      ? `+${move.priority}`
                                      : move.priority
                                    : "-"}
                                </td>
                              </tr>
                            ))}
                          </tbody>
                        </table>
                      </div>
                    )}
                  </section>

                  {/* Tutor moves */}
                  <section>
                    <h4 className="text-xs font-semibold text-emerald-300 mb-2">
                      Movimentos de Tutor
                    </h4>
                    {groupedMoves.tutor.length === 0 ? (
                      <p className="text-[11px] text-slate-400">
                        Nenhum movimento de tutor.
                      </p>
                    ) : (
                      <div className="overflow-x-auto rounded-lg border border-slate-800">
                        <table className="min-w-full text-[11px]">
                          <thead className="bg-slate-900/80">
                            <tr className="text-left text-slate-300">
                              <th className="px-3 py-2">Movimento</th>
                              <th className="px-3 py-2">Tipo</th>
                              <th className="px-3 py-2 text-right">Power</th>
                              <th className="px-3 py-2 text-right">Acc</th>
                              <th className="px-3 py-2 text-right">PP</th>
                              <th className="px-3 py-2">Classe</th>
                              <th className="px-3 py-2">Prio</th>
                            </tr>
                          </thead>
                          <tbody>
                            {groupedMoves.tutor.map(({ entry, move }) => (
                              <tr
                                key={entry.moveId}
                                className="border-t border-slate-800/60"
                              >
                                <td className="px-3 py-1.5 text-slate-100">
                                  {move.name}
                                </td>
                                <td className="px-3 py-1.5">
                                  <span className="rounded-full bg-slate-800 px-2 py-0.5 text-[10px] text-slate-100">
                                    {typeBadges(move.type)}
                                  </span>
                                </td>
                                <td className="px-3 py-1.5 text-right">
                                  {move.power ?? "-"}
                                </td>
                                <td className="px-3 py-1.5 text-right">
                                  {move.accuracy ?? "-"}
                                </td>
                                <td className="px-3 py-1.5 text-right">
                                  {move.pp ?? "-"}
                                </td>
                                <td className="px-3 py-1.5">
                                  {damageClassLabel(move.damageClass)}
                                </td>
                                <td className="px-3 py-1.5">
                                  {move.priority && move.priority !== 0
                                    ? move.priority > 0
                                      ? `+${move.priority}`
                                      : move.priority
                                    : "-"}
                                </td>
                              </tr>
                            ))}
                          </tbody>
                        </table>
                      </div>
                    )}
                  </section>
                </div>
              )}
            </div>
          )}

          {/* Config */}
          {activeTab === "config" && config && (
            <div className="space-y-4 text-xs">
              {/* Disponibilidade */}
              <section className="border border-slate-800 rounded-md px-3 py-2">
                <h3 className="text-xs font-semibold text-slate-300 mb-1">
                  Disponibilidade
                </h3>
                <label className="flex items-center gap-2 text-xs">
                  <input
                    type="checkbox"
                    checked={config.available}
                    onChange={(e) =>
                      setConfig({ ...config, available: e.target.checked })
                    }
                  />
                  Disponível para captura nesta versão
                </label>

                <div className="mt-2 grid grid-cols-2 gap-2 text-xs">
                  <div>
                    <label className="block text-slate-400 mb-1">
                      Nível mínimo
                    </label>
                    <input
                      type="number"
                      min={1}
                      max={100}
                      className="w-full rounded-md bg-slate-900 border border-slate-700 px-2 py-1 text-xs"
                      value={config.levelMin ?? ""}
                      onChange={(e) =>
                        setConfig({
                          ...config,
                          levelMin:
                            e.target.value === ""
                              ? null
                              : Number(e.target.value),
                        })
                      }
                    />
                  </div>
                  <div>
                    <label className="block text-slate-400 mb-1">
                      Nível máximo
                    </label>
                    <input
                      type="number"
                      min={1}
                      max={100}
                      className="w-full rounded-md bg-slate-900 border border-slate-700 px-2 py-1 text-xs"
                      value={config.levelMax ?? ""}
                      onChange={(e) =>
                        setConfig({
                          ...config,
                          levelMax:
                            e.target.value === ""
                              ? null
                              : Number(e.target.value),
                        })
                      }
                    />
                  </div>
                </div>
              </section>

              {/* Status dinâmicos */}
              <section className="border border-slate-800 rounded-md px-3 py-2 space-y-2">
                <h3 className="text-xs font-semibold text-slate-300">
                  Status dinâmicos (IV / EV / Natureza / Habilidade)
                </h3>

                <div className="grid grid-cols-3 gap-2 text-xs items-end">
                  <div className="col-span-1">
                    <label className="block text-slate-400 mb-1">IV</label>
                    <select
                      className="w-full rounded-md bg-slate-900 border border-slate-700 px-2 py-1 text-xs"
                      value={config.ivMode}
                      onChange={(e) =>
                        setConfig({
                          ...config,
                          ivMode: e.target.value as IvMode,
                        })
                      }
                    >
                      <option value="random">Aleatório (0–31)</option>
                      <option value="range">Intervalo personalizado</option>
                    </select>
                  </div>
                  {config.ivMode === "range" && (
                    <>
                      <div>
                        <label className="block text-slate-400 mb-1">
                          IV mínimo
                        </label>
                        <input
                          type="number"
                          min={0}
                          max={31}
                          className="w-full rounded-md bg-slate-900 border border-slate-700 px-2 py-1 text-xs"
                          value={config.ivMin}
                          onChange={(e) =>
                            setConfig({
                              ...config,
                              ivMin: Number(e.target.value),
                            })
                          }
                        />
                      </div>
                      <div>
                        <label className="block text-slate-400 mb-1">
                          IV máximo
                        </label>
                        <input
                          type="number"
                          min={0}
                          max={31}
                          className="w-full rounded-md bg-slate-900 border border-slate-700 px-2 py-1 text-xs"
                          value={config.ivMax}
                          onChange={(e) =>
                            setConfig({
                              ...config,
                              ivMax: Number(e.target.value),
                            })
                          }
                        />
                      </div>
                    </>
                  )}
                </div>

                <div className="grid grid-cols-2 gap-2 text-xs items-end">
                  <div>
                    <label className="block text-slate-400 mb-1">EV</label>
                    <select
                      className="w-full rounded-md bg-slate-900 border border-slate-700 px-2 py-1 text-xs"
                      value={config.evMode}
                      onChange={(e) =>
                        setConfig({
                          ...config,
                          evMode: e.target.value as EvMode,
                        })
                      }
                    >
                      <option value="none">Sem EV (0)</option>
                      <option value="default">
                        Distribuição padrão por classe
                      </option>
                    </select>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-2 text-xs items-end">
                  <div>
                    <label className="block text-slate-400 mb-1">
                      Natureza
                    </label>
                    <select
                      className="w-full rounded-md bg-slate-900 border border-slate-700 px-2 py-1 text-xs"
                      value={config.natureMode}
                      onChange={(e) =>
                        setConfig({
                          ...config,
                          natureMode: e.target.value as "any" | "restricted",
                        })
                      }
                    >
                      <option value="any">Aleatória (todas)</option>
                      <option value="restricted">Lista restrita</option>
                    </select>
                  </div>
                  {config.natureMode === "restricted" && (
                    <div>
                      <label className="block text-slate-400 mb-1">
                        Naturezas permitidas
                      </label>
                      <input
                        type="text"
                        placeholder="Ex.: Adamant, Jolly..."
                        className="w-full rounded-md bg-slate-900 border border-slate-700 px-2 py-1 text-xs"
                        value={config.allowedNatures.join(", ")}
                        onChange={(e) =>
                          setConfig({
                            ...config,
                            allowedNatures: e.target.value
                              .split(",")
                              .map((n) => n.trim())
                              .filter(Boolean),
                          })
                        }
                      />
                    </div>
                  )}
                </div>

                <div className="grid grid-cols-2 gap-2 text-xs items-end">
                  <div>
                    <label className="block text-slate-400 mb-1">
                      Habilidade
                    </label>
                    <select
                      className="w-full rounded-md bg-slate-900 border border-slate-700 px-2 py-1 text-xs"
                      value={config.abilityMode}
                      onChange={(e) =>
                        setConfig({
                          ...config,
                          abilityMode:
                            e.target.value as PokemonConfig["abilityMode"],
                        })
                      }
                    >
                      <option value="randomNormal">
                        Aleatória (habilidades normais)
                      </option>
                      <option value="noHidden">
                        Não permitir habilidade oculta
                      </option>
                      <option value="fixed">Sempre habilidade fixa</option>
                    </select>
                  </div>
                  {config.abilityMode === "fixed" && (
                    <div>
                      <label className="block text-slate-400 mb-1">
                        Nome da habilidade
                      </label>
                      <input
                        type="text"
                        placeholder="Ex.: Overgrow"
                        className="w-full rounded-md bg-slate-900 border border-slate-700 px-2 py-1 text-xs"
                        value={config.fixedAbilityName ?? ""}
                        onChange={(e) =>
                          setConfig({
                            ...config,
                            fixedAbilityName: e.target.value.trim() || null,
                          })
                        }
                      />
                    </div>
                  )}
                </div>
              </section>

              {/* Quantidade & probabilidades */}
              <section className="border border-slate-800 rounded-md px-3 py-2 space-y-2">
                <h3 className="text-xs font-semibold text-slate-300">
                  Quantidade e probabilidades
                </h3>

                <div className="grid grid-cols-2 gap-2 text-xs">
                  <div>
                    <label className="block text-slate-400 mb-1">
                      Quantidade disponível
                    </label>
                    <input
                      type="number"
                      min={0}
                      className="w-full rounded-md bg-slate-900 border border-slate-700 px-2 py-1 text-xs"
                      value={config.quantityLimit ?? ""}
                      onChange={(e) =>
                        setConfig({
                          ...config,
                          quantityLimit:
                            e.target.value === ""
                              ? null
                              : Number(e.target.value),
                        })
                      }
                      disabled={config.unlimitedQuantity}
                    />
                    <label className="mt-1 flex items-center gap-1 text-[11px] text-slate-400">
                      <input
                        type="checkbox"
                        checked={config.unlimitedQuantity}
                        onChange={(e) =>
                          setConfig({
                            ...config,
                            unlimitedQuantity: e.target.checked,
                          })
                        }
                      />
                      Ilimitado
                    </label>
                  </div>

                  <div>
                    <label className="block text-slate-400 mb-1">
                      % Aparição (base)
                    </label>
                    <input
                      type="number"
                      min={0}
                      max={100}
                      step={0.01}
                      className="w-full rounded-md bg-slate-900 border border-slate-700 px-2 py-1 text-xs"
                      value={config.appearanceRate}
                      onChange={(e) =>
                        setConfig({
                          ...config,
                          appearanceRate: Number(e.target.value),
                        })
                      }
                    />
                  </div>

                  <div>
                    <label className="block text-slate-400 mb-1">% Shiny</label>
                    <input
                      type="number"
                      min={0}
                      max={100}
                      step={0.0001}
                      className="w-full rounded-md bg-slate-900 border border-slate-700 px-2 py-1 text-xs"
                      value={config.shinyRate}
                      onChange={(e) =>
                        setConfig({
                          ...config,
                          shinyRate: Number(e.target.value),
                        })
                      }
                    />
                  </div>

                  <div>
                    <label className="block text-slate-400 mb-1">
                      % Corrompido
                    </label>
                    <input
                      type="number"
                      min={0}
                      max={100}
                      step={0.01}
                      className="w-full rounded-md bg-slate-900 border border-slate-700 px-2 py-1 text-xs"
                      value={config.corruptedRate}
                      onChange={(e) =>
                        setConfig({
                          ...config,
                          corruptedRate: Number(e.target.value),
                        })
                      }
                    />
                  </div>

                  <div>
                    <label className="block text-slate-400 mb-1">
                      % Glamour
                    </label>
                    <input
                      type="number"
                      min={0}
                      max={100}
                      step={0.01}
                      className="w-full rounded-md bg-slate-900 border border-slate-700 px-2 py-1 text-xs"
                      value={config.glamourRate}
                      onChange={(e) =>
                        setConfig({
                          ...config,
                          glamourRate: Number(e.target.value),
                        })
                      }
                    />
                  </div>
                </div>

                <p className="mt-1 text-[10px] text-slate-500">
                  O Robô de Lançamento usa estes valores como base. Eventos e
                  sazonais podem sobrescrever temporariamente essas taxas.
                </p>
              </section>

              {/* Métodos de encontro */}
              <section className="border border-slate-800 rounded-md px-3 py-2 space-y-2">
                <h3 className="text-xs font-semibold text-slate-300">
                  Regras por método de encontro
                </h3>

                {/* Radar */}
                <div className="border border-slate-800/80 rounded-md px-2 py-1 text-xs space-y-1">
                  <div className="flex items-center justify-between">
                    <span className="font-semibold text-slate-200">Radar</span>
                    <label className="flex items-center gap-1 text-[11px] text-slate-400">
                      <input
                        type="checkbox"
                        checked={config.methods.radar.enabled}
                        onChange={(e) =>
                          setConfig({
                            ...config,
                            methods: {
                              ...config.methods,
                              radar: {
                                ...config.methods.radar,
                                enabled: e.target.checked,
                              },
                            },
                          })
                        }
                      />
                      Ativo
                    </label>
                  </div>
                  {config.methods.radar.enabled && (
                    <div className="mt-1">
                      <label className="block text-slate-400 mb-1">
                        % Aparição específica (opcional)
                      </label>
                      <input
                        type="number"
                        min={0}
                        max={100}
                        step={0.01}
                        className="w-full rounded-md bg-slate-900 border border-slate-700 px-2 py-1 text-xs"
                        value={config.methods.radar.appearanceRate ?? ""}
                        onChange={(e) =>
                          setConfig({
                            ...config,
                            methods: {
                              ...config.methods,
                              radar: {
                                ...config.methods.radar,
                                appearanceRate:
                                  e.target.value === ""
                                    ? null
                                    : Number(e.target.value),
                              },
                            },
                          })
                        }
                      />
                    </div>
                  )}
                </div>

                {/* KM */}
                <div className="border border-slate-800/80 rounded-md px-2 py-1 text-xs space-y-1">
                  <div className="flex items-center justify-between">
                    <span className="font-semibold text-slate-200">
                      KM percorrida
                    </span>
                    <label className="flex items-center gap-1 text-[11px] text-slate-400">
                      <input
                        type="checkbox"
                        checked={config.methods.km.enabled}
                        onChange={(e) =>
                          setConfig({
                            ...config,
                            methods: {
                              ...config.methods,
                              km: {
                                ...config.methods.km,
                                enabled: e.target.checked,
                              },
                            },
                          })
                        }
                      />
                      Ativo
                    </label>
                  </div>
                  {config.methods.km.enabled && (
                    <div className="mt-1">
                      <label className="block text-slate-400 mb-1">
                        KM mínima para liberar
                      </label>
                      <input
                        type="number"
                        min={0}
                        className="w-full rounded-md bg-slate-900 border border-slate-700 px-2 py-1 text-xs"
                        value={config.methods.km.minKm ?? ""}
                        onChange={(e) =>
                          setConfig({
                            ...config,
                            methods: {
                              ...config.methods,
                              km: {
                                ...config.methods.km,
                                minKm:
                                  e.target.value === ""
                                    ? null
                                    : Number(e.target.value),
                              },
                            },
                          })
                        }
                      />
                    </div>
                  )}
                </div>

                {/* Vara de pescar */}
                <div className="border border-slate-800/80 rounded-md px-2 py-1 text-xs space-y-1">
                  <div className="flex items-center justify-between">
                    <span className="font-semibold text-slate-200">
                      Vara de Pescar
                    </span>
                    <label className="flex items-center gap-1 text-[11px] text-slate-400">
                      <input
                        type="checkbox"
                        checked={config.methods.rod.enabled}
                        onChange={(e) =>
                          setConfig({
                            ...config,
                            methods: {
                              ...config.methods,
                              rod: {
                                ...config.methods.rod,
                                enabled: e.target.checked,
                              },
                            },
                          })
                        }
                      />
                      Ativo
                    </label>
                  </div>
                  {config.methods.rod.enabled && (
                    <div className="mt-1">
                      <label className="block text-slate-400 mb-1">
                        % Chance de falha
                      </label>
                      <input
                        type="number"
                        min={0}
                        max={100}
                        step={0.01}
                        className="w-full rounded-md bg-slate-900 border border-slate-700 px-2 py-1 text-xs"
                        value={config.methods.rod.failureChance ?? ""}
                        onChange={(e) =>
                          setConfig({
                            ...config,
                            methods: {
                              ...config.methods,
                              rod: {
                                ...config.methods.rod,
                                failureChance:
                                  e.target.value === ""
                                    ? null
                                    : Number(e.target.value),
                              },
                            },
                          })
                        }
                      />
                    </div>
                  )}
                </div>

                {/* Ovos */}
                <div className="border border-slate-800/80 rounded-md px-2 py-1 text-xs space-y-1">
                  <div className="flex items-center justify-between">
                    <span className="font-semibold text-slate-200">Ovos</span>
                    <label className="flex items-center gap-1 text-[11px] text-slate-400">
                      <input
                        type="checkbox"
                        checked={config.methods.egg.enabled}
                        onChange={(e) =>
                          setConfig({
                            ...config,
                            methods: {
                              ...config.methods,
                              egg: {
                                ...config.methods.egg,
                                enabled: e.target.checked,
                              },
                            },
                          })
                        }
                      />
                      Ativo
                    </label>
                  </div>
                  {config.methods.egg.enabled && (
                    <label className="mt-1 flex items-center gap-1 text-[11px] text-slate-400">
                      <input
                        type="checkbox"
                        checked={config.methods.egg.fromMysteryEgg}
                        onChange={(e) =>
                          setConfig({
                            ...config,
                            methods: {
                              ...config.methods,
                              egg: {
                                ...config.methods.egg,
                                fromMysteryEgg: e.target.checked,
                              },
                            },
                          })
                        }
                      />
                      Pode sair de Ovo Misterioso
                    </label>
                  )}
                </div>
              </section>
            </div>
          )}
        </div>

        {activeTab === "config" && config && (
          <div className="border-t border-slate-800 px-5 py-3 flex items-center justify-between">
            <span className="text-[11px] text-slate-400">
              Alterações afetam apenas encontros futuros.
            </span>
            <button
              type="button"
              disabled={saving}
              onClick={handleSave}
              className="px-3 py-1.5 rounded-md bg-emerald-600 hover:bg-emerald-500 text-xs font-semibold text-white disabled:opacity-60"
            >
              {saving ? "Salvando..." : "Salvar configuração"}
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
