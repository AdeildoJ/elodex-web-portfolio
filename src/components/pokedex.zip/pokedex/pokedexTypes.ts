// src/components/pokedex/pokedexTypes.ts

export type PokemonType =
  | "normal"
  | "fire"
  | "water"
  | "electric"
  | "grass"
  | "ice"
  | "fighting"
  | "poison"
  | "ground"
  | "flying"
  | "psychic"
  | "bug"
  | "rock"
  | "ghost"
  | "dragon"
  | "dark"
  | "steel"
  | "fairy";

export const ALL_TYPES: PokemonType[] = [
  "normal",
  "fire",
  "water",
  "electric",
  "grass",
  "ice",
  "fighting",
  "poison",
  "ground",
  "flying",
  "psychic",
  "bug",
  "rock",
  "ghost",
  "dragon",
  "dark",
  "steel",
  "fairy",
];

export type PokemonSpecies = {
  id: string;
  dexNumber: number;
  name: string;
  types: PokemonType[];
  pokemonClass?: string;
  spriteUrl?: string | null;
  shinySpriteUrl?: string | null;
  dexEntryPtBr?: string | null;
  baseStats?: {
    hp: number;
    attack: number;
    defense: number;
    specialAttack: number;
    specialDefense: number;
    speed: number;
  };
  height?: number;
  weight?: number;
};
